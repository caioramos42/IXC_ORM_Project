# import requests
# from dotenv import load_dotenv
# import os
# import base64

# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# load_dotenv()

# host = str(os.getenv("IXC_HOST"))
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# url = f"https://{host}/webservice/v1/fn_feriados"

# payload = {
#     "qtype" : "fn_feriados.id",
#     "query" : "0",
#     "oper" : ">=",
#     "page" : "1",
#     "rp" : "20000",
#     "sortname" : "fn_feriados.id",
#     "sortorder" : "desc"
# }
# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }
# response = requests.post(url, headers=headers, json=payload, verify=False)

# with open("feriados.json", "w") as file:
#     file.write(response.text)

# print(response.text)

import requests
from dotenv import load_dotenv
import os
import base64

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv()

host = str(os.getenv("IXC_HOST"))
token = os.getenv("IXC_TOKEN").encode('utf-8')

url = f"https://{host}/webservice/v1/sva_usuarios"

payload = {
    "qtype" : "sva_usuarios.id",
    "query" : "0",
    "oper" : ">=",
    "page" : "1",
    "rp" : "20000",
    "sortname" : "sva_usuarios.id",
    "sortorder" : "desc"
}
headers = {
    'ixcsoft': 'listar',
    'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
    'Content-Type': 'application/json'
}
response = requests.post(url, headers=headers, json=payload, verify=False)

with open("tvssva.json", "w") as file:
    file.write(response.text)

print(response.text)