from datetime import datetime, timedelta
from ORM_IXC.models.tableModels.contratoDoClienteModel import ContratoDoClienteModel
from ORM_IXC.context.contextModels.contratoDoCliente import ContratoDoCliente
from ORM_IXC.models.tableModels.clienteModel import ClientModel
from ORM_IXC.context.contextModels.cliente import Cliente
from ORM_IXC.models.tableModels.atendimentoModel import AtendimentoModel
from ORM_IXC.context.contextModels.atendimento import Atendimento
from ORM_IXC.context.contextModels.radacct import Radacct
from ORM_IXC.models.tableModels.radacctModel import RadacctModel
from ORM_IXC.context.contextModels.login import Login
from ORM_IXC.models.tableModels.loginModel import LoginModel
from ORM_IXC.context.request.manager import Manager
from ORM_IXC.statemants.CRUD.select import select
from ORM_IXC.statemants.sqlFunctions.distinct import distinct
from ORM_IXC.statemants.sqlFunctions.count import count
import os
from dotenv import load_dotenv
from ORM_IXC.utils.makejson import makeJson
from collections import Counter

load_dotenv()

host = str(os.getenv("IXC_HOST"))
token = str(os.getenv("IXC_TOKEN"))   

manager = Manager(host, token)
radacct = Radacct(manager)
contrato = ContratoDoCliente(manager)
login = Login(manager)
atendimento = Atendimento(manager)
cliente = Cliente(manager)

yesterday = (datetime.now() - timedelta(days=2)).strftime('%Y/%m/%d')

# query = select(radacct)\
#     .where(
#         (RadacctModel.acctsessionid > 0) 
#     )\
#     .order_by("acctsessionid")\
#     .limit(3000)\
#     .execute()


# print(query)

# import sys
# import os
# from dotenv import load_dotenv
# #ixc_logs
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# load_dotenv()

# import requests
# import base64
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# host = os.getenv("IXC_HOST")
# url = "https://{}/webservice/v1/radacct".format(host)
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# payload = {
#     'qtype': 'radacct.radacctid',
#     'query': '0',
#     'oper': '>',
#     'page': '1',
#     'rp': '3000',
#     'sortname': 'radacct.radacctid',
#     'sortorder': 'asc'
# }

# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# import requests

# url = f"https://{host}/webservice/v1/radacct"

# response = requests.post(url, json=payload, headers=headers, verify=False)


# print(response.text)

query = select(radacct)\
    .where(
        (RadacctModel.acctstoptime == '2025-08-04 13:04:18') 
    )\
    .order_by("acctsessionid")\
    .limit(3000)\
    .execute()
