import sys
import os
from dotenv import load_dotenv
#ixc_logs
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
load_dotenv()

import requests
import base64
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

host = os.getenv("IXC_HOST")
url = "https://{}/webservice/v1/veiculos".format(host)
token = os.getenv("IXC_TOKEN").encode('utf-8')

payload = {
    'qtype': 'veiculos.id',
    'query': '0',
    'oper': '>',
    'page': '1',
    'rp': '2000',
    'sortname': 'veiculos.id',
    'sortorder': 'asc'
}

headers = {
    'ixcsoft': 'listar',
    'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
    'Content-Type': 'application/json'
}

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)

import requests

url = f"https://{host}/webservice/v1/veiculos"

# payload = {
#             "data_proxima_revisao": "0000-00-00",
#             "aviso_troca_oleo_dias_antes": "0",
#             "aviso_revisao_dias_antes": "0",
#             "intervalo_dias_entre_revisoes": "0",
#             "status": "A",
#             "id_filial": "1",
#             "uf_veiculo": "17",
#             "descricao": "CHEVROLETT/CLASSIC",
#             "oleo": "5000",
#             "renavam": "323265946",
#             "tara": "0.00",
#             "placa_tipo": "MERCOSUL",
#             "placa": "KZU1C59",
#             "capacidade_kg": "0.00",
#             "capacidade_m3": "0.00",
#             "condutor_principal": "0",
#             "tipo_rodado": "",
#             "ano_fabricacao": "0",
#             "tipo_carroceria": "",
#             "ano_modelo": "0",
#             "numero_crv": "",
#             "cor": "Branco",
#             "chassi": "",
#             "reastreador": "356354870688620",
#             "data_aquisicao": "0000-00-00",
#             "status_veiculos": "on",
#             "data_venda": "0000-00-00",
#             "placa_anterior": "",
#             "combustivel_tipo": "GASOLINA",
#             "caminhao_qtde_eixos": "2",
#             "categoria_veiculo": "CARRO",
#             "hodometro": "0.000",
#             "observacao": "",
#             "data_revisao": "0000-00-00",
#             "data_proxima_troca_oleo": "0000-00-00",
#             "data_ultima_troca_oleo": "0000-00-00",
#             "centro_custo_regra_rateio": "CE",
#             "id_centro_custo_criterio_rateio": "0",
#             "id_centro_custo_rel_centro_custo_categoria_padrao": "0",
#             "id_centro_custo_categoria_filtro": "0"
#         }
response = requests.post(url, json=payload, headers=headers, verify=False)


print(response.text)

# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)




# import sys
# import os
# from dotenv import load_dotenv

# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# load_dotenv()

# import requests
# import base64
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# host = os.getenv("IXC_HOST")
# url = "https://{}/webservice/v1/integracoes_redes".format(host)
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# payload = {
#     'qtype': 'integracoes_redes.id',
#     'query': '0',
#     'oper': '>',
#     'page': '1',
#     'rp': '2000',
#     'sortname': 'integracoes_redes.id',
#     'sortorder': 'asc'
# }

# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)

# with open("integr.json", "w") as file:
#     file.write(response.text)

# host = os.getenv("IXC_HOST")
# url = "https://{}/webservice/v1/botaoAjax_22282".format(host)
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# host = os.getenv("IXC_HOST")
# url = "https://{}/webservice/v1/ixc_logs".format(host)
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# payload ={
#     "qtype": "ixc_logs.id",
#     "query": "1",
#     "oper": ">=",
#     "page": "1",
#     "rp": "1000",
#     "sortname": "ixc_logs.id",
#     "sortorder": "desc"
# }

# payload = {
#     "tipo_envio_mensagem": "sms",
#     "celular": "(35) 99710-1358",
#     "id_gateway": "1",
#     "mensagem": "Teste API",
#     "remetente": "",
#     "id_cliente": "32099"
# }

# headers = {
#     'ixcsoft': '',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)

# with open("integr.json", "w") as file:
#     file.write(response.text)
 