# import sys
# import os
# from dotenv import load_dotenv
#ixc_logs
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
# load_dotenv()

# import requests
# import base64
# import urllib3
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# host = os.getenv("IXC_HOST")
# url = "https://{}/webservice/v1/veiculos".format(host)
# token = os.getenv("IXC_TOKEN").encode('utf-8')

# payload = {
#     'qtype': 'veiculos.id',
#     'query': '0',
#     'oper': '>',
#     'page': '1',
#     'rp': '2000',
#     'sortname': 'veiculos.id',
#     'sortorder': 'asc'
# }




# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)
# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }

# response = requests.post(url, json=payload, headers=headers, verify=False)

# print(response.text)




import sys
import os
from dotenv import load_dotenv

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
load_dotenv()

import requests
import base64
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

host = os.getenv("IXC_HOST")
url = "https://{}/webservice/v1/integracoes_redes".format(host)
token = os.getenv("IXC_TOKEN").encode('utf-8')

payload = {
    'qtype': 'integracoes_redes.id',
    'query': '0',
    'oper': '>',
    'page': '1',
    'rp': '2000',
    'sortname': 'integracoes_redes.id',
    'sortorder': 'asc'
}

headers = {
    'ixcsoft': 'listar',
    'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
    'Content-Type': 'application/json'
}

response = requests.post(url, json=payload, headers=headers, verify=False)

print(response.text)

with open("integr.json", "w") as file:
    file.write(response.text)