from __future__ import annotations

from ORM_IXC.statemants.CRUD.select import select
from ORM_IXC.statemants.maps.classBase import Field
from ORM_IXC.models.searchUtils.searchModel import SearchModule


class ParentModel:
    id = Field(name="id", fieldType=int)


class ChildModel:
    id = Field(name="id", fieldType=int)
    parent_id = Field(name="parent_id", fieldType=int)
    active = Field(name="active", fieldType=str)


ParentModel.id.model = ParentModel
ChildModel.id.model = ChildModel
ChildModel.parent_id.model = ChildModel
ChildModel.active.model = ChildModel


class FakeRow:
    def __init__(self, row_id: int, parent_id: int | None = None, active: str | None = None) -> None:
        self.id = row_id
        self.parent_id = parent_id
        self.active = active
        self._inners: list[object] = []

    def inner(self, row: object) -> None:
        self._inners.append(row)


class FakeContext:
    def __init__(self, rows: list[FakeRow]) -> None:
        self.rows = rows
        self.contextModel = None

    def SelectByFilter(self, search: SearchModule) -> list[FakeRow]:
        if search.searchField == "id":
            return [row for row in self.rows if row.id > 0]

        if search.searchField == "parent_id":
            allowed_ids = {int(value.strip()) for value in search.query.split(",") if value.strip()}
            filtered = [row for row in self.rows if getattr(row, "parent_id") in allowed_ids]
            if search._filter_tree:
                active_filter = next(
                    (item for item in search._filter_tree if item.get("TB") == "active"),
                    None,
                )
                if active_filter is not None and active_filter.get("P") != "Y":
                    return []
                if active_filter is not None and active_filter.get("P") == "Y":
                    filtered = [row for row in filtered if getattr(row, "active") == "Y"]
            return filtered

        return []

    def SelectAll(self) -> list[FakeRow]:
        return list(self.rows)

    def SelectAllAssync(self):
        return iter(self.rows)

    def SelectByFilterAssync(self, search: SearchModule, page_size: int):
        return iter(self.SelectByFilter(search))

    def Add(self, obj):
        return obj

    def Update(self, obj, search):
        return obj

    def Delete(self, search):
        return []

    def DeleteById(self, id):
        return id


def test_join_accepts_filter_on_joined_table():
    parent_context = FakeContext([FakeRow(1), FakeRow(2)])
    child_context = FakeContext([
        FakeRow(10, parent_id=1, active="Y"),
        FakeRow(11, parent_id=1, active="N"),
    ])

    rows = (
        select(parent_context)
        .where(ParentModel.id > 0)
        .join(
            child_context,
            ParentModel.id == ChildModel.parent_id,
            ChildModel.active == "Y",
        )
        .execute()
    )

    assert len(rows) == 1
    assert rows[0]._inners[0].id == 10
    assert rows[0]._inners[0].active == "Y"


def test_left_join_keeps_parent_rows_without_matches():
    parent_context = FakeContext([FakeRow(1), FakeRow(2)])
    child_context = FakeContext([])

    rows = (
        select(parent_context)
        .where(ParentModel.id > 0)
        .join(
            child_context,
            ParentModel.id == ChildModel.parent_id,
            ChildModel.active == "Y",
            join_type="left",
        )
        .execute()
    )

    assert len(rows) == 2
    assert all(len(row._inners) == 0 for row in rows)
