import requests
from dotenv import load_dotenv
import os
import base64

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

load_dotenv()

host = str(os.getenv("IXC_HOST"))
token = os.getenv("IXC_TOKEN").encode('utf-8')

#url = f"https://{host}/webservice/v1/botao_rel_26658"
url = f"https://{host}/webservice/v1/botaoAjax_22282"
#url = f"https://{host}/webservice/v1/usuarios_grupo"
# payload = {
#   "tipo_notificacao":"G",
#   "titulo": "TESTE API",
#   "mensagem": "TESTANDO API",
#   "id_cliente": "1228",
# }

# payload = {
#   "id_gateway": "1",
#   "id_gateway_label": "hotmobile",
#   "mensagem": "Teste",
#   "remetente": "Br Like",
#   "celular": "35997101358",
#   "id_cliente": "32099"
# }

# payload = {
#   "tipo_envio_mensagem": "omnichannel",
#   "celular": "35997101358",
#   "id_cliente": "32099",
#   "msg_omnichannel": "24",
#   "msg_omnichannel_label": "Teste"
# }

# payload  = {
#     'qtype': 'usuarios_grupo.id',
#     'query': '1',
#     'oper': '>',
#     'page': '1',
#     'rp': '20',
#     'sortname': 'usuarios_grupo.id',
#     'sortorder': 'desc'
# }


headers = {
    'ixcsoft': '',
    'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
    'Content-Type': 'application/json'
}

# response = requests.get(
#     "https://ixc.brasillike.com.br/webservice/v1/arquivos/willian2.jpg",
#     headers=headers,
#     verify=False
# )

# print(response.text)

# response = requests.get(f"https://{host}/webservice/v1", headers=headers, verify=False)

# print(response.text)

#response = requests.post(url, headers=headers, json=payload, verify=False)

# response = requests.get("https://ixc.brasillike.com.br/webservice/v1/usuarios_grupo/1", headers=headers, verify=False)

#print(response.text)

# payload = {"tipo_notificacao":"G",
#            "titulo":"TESTE",
#            "mensagem":"push",
#            "token_firebase":"d2zvsKpQx2U:APA91bHhyT_Q_lDse-YZUwxAUtTyHas0X5SPIYInuIGNFWKdpabbKpJ4wWxKyH9K0-xpbrRlfxdRipXNceuGJMscK74JqgjBV5CaRYBQhC2FKBhsQzb63FOBSkHG3r1li9jP6fSmdV98",
#            "data_criacao":"2022-06-11 09:06:23",
#            "data_envio":"2022-06-11 09:06:23",
#            "status":"E",
#            "id_cliente":"32099",
#            "retorno_envio_push":"0:1654950923800636%d3ebae83d3ebae83",
#            "request":"/aplicativo/enviar_notificacao_push/action/action.php?action=botaoAjax_26658"}
 
 
 #-------------------------------LOGS------------------------------------#
url = f'https://{host}/webservice/v1/ixc_logs'
payload = {
  "qtype": "ixc_logs.id",
  "query": "1",
  "oper": ">=",
  "page": "1",
  "rp": "1000",
  "sortname": "ixc_logs.id",
  "sortorder": "desc"
}
headers = {
    'ixcsoft': 'listar',
    'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
    'Content-Type': 'application/json'
}
response = requests.post(url, headers=headers, json=payload, verify=False)

print(response.text)
with open("mylogs.json", "w") as file:
   file.write(response.text)
  

#---------------------------------PERMISSOES BOTOES------------------------------------------#
# url = f'https://{host}/webservice/v1/ixc_permissoes'
# payload = {
#   "qtype": "ixc_permissoes.id",
#   "query": "1",
#   "oper": ">=",
#   "page": "1",
#   "rp": "1000",
#   "sortname": "ixc_permissoes.id",
#   "sortorder": "desc"
# }
# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }
# response = requests.post(url, headers=headers, json=payload, verify=False)

# print(response.text)
# with open("permissions.json", "w") as file:
#   file.write(response.text)
  
#-----------------------------PATRIMONIO-------------------------------------#
# url = f'https://{host}/webservice/v1/patrimonio'
# payload = {
#   "qtype": "patrimonio.id",
#   "query": "1",
#   "oper": ">=",
#   "page": "1",
#   "rp": "1000",
#   "sortname": "patrimonio.id",
#   "sortorder": "desc"
# }
# headers = {
#     'ixcsoft': 'listar',
#     'Authorization': 'Basic {}'.format(base64.b64encode(token).decode('utf-8')),
#     'Content-Type': 'application/json'
# }
# response = requests.post(url, headers=headers, json=payload, verify=False)

# print(response.text)
# with open("patrimonio.json", "w") as file:
#   file.write(response.text)

# print(response.text)